package com.example.finalproject2.ui.home;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.example.finalproject2.R;
import com.example.finalproject2.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    // Inside the onCreateView() method of your fragment
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Get the button from the layout
        Button pizza = view.findViewById(R.id.andpizza);

        // Set an OnClickListener on the button
        pizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the modal
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.andpizzamodal);

                dialog.show();
            }
        });

        Button carvingsbtn = view.findViewById(R.id.carvings);

        // Set an OnClickListener on the button
        carvingsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the modal
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.carvingsmodal);

                dialog.show();
            }
        });

        Button chipotlebtn = view.findViewById(R.id.chipotlemodal);

        // Set an OnClickListener on the button
        chipotlebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the modal
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.chipotlemodal);

                dialog.show();
            }
        });
        Button sweetgreenmodalbtn = view.findViewById(R.id.sweetgreenmodal);

        // Set an OnClickListener on the button
        sweetgreenmodalbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the modal
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.sweetgreenmodal);

                dialog.show();
            }
        });
        Button beefsteakmodalbtn = view.findViewById(R.id.beefsteakmodal);

        // Set an OnClickListener on the button
        beefsteakmodalbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the modal
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.beefsteakmodal);

                dialog.show();
            }
        });
        Button bindaasmodalbtn = view.findViewById(R.id.bindaasmodal);

        // Set an OnClickListener on the button
        bindaasmodalbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create the modal
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.bindaasmodal);

                dialog.show();
            }
        });



        return view;
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


}
